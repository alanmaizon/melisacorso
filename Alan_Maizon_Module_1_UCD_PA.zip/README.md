UDC PA Module 1 - Web Development
  -- Melisa Corso Webpage --
Includes the following features:
- CSS and HTML estructure
- Clear navigation
- Library of modern icons
- Defined header, footer, navigation and content
- Dinamic internal taxonomy
- Contact forms, social media links
- Responsive in all browsers

Resources used for this proyect:
- https://icomoon.io/
- https://www.meta.ai/
- https://www.falconmasters.com/
- https://www.adobe.com/
- https://www.figma.com/
- https://octopus.do/
- https://developer.mozilla.org/
- https://www.w3schools.com/
- https://stackoverflow.com/
- https://validator.w3.org/



